from universal.algo import Algo
import numpy as np


class ReversalTrend(Algo):
    PRICE_TYPE = 'log'

    # if true, replace missing values by last values
    REPLACE_MISSING = True

    def __init__(self, m=12, n=26):
        if n <= m:
            raise ValueError('n parameter must be > m')
        # n,m length of exponential moving average
        self.m = m
        self.n = n
        super(ReversalTrend, self).__init__(min_history=n)

    def init_weights(self, columns):
        return pd.Series(np.ones(len(columns)) / len(columns), columns)

    def weights(self, S):
        # Building exponential moving average m on Stock S
        def EMA(m, S):
            S_ewm = S.ewm(span=m, adjust=False).mean()
            return S_ewm

        # calculate exponential moving average m
        ema_m = EMA(self.m, S)

        # calculate exponential moving average n
        ema_n = EMA(self.n, S)

        # calculate exponential moving average (n+m)/2
        ema_mean = EMA(int((self.m + self.n) / 2), S)

        delta_1 = S - ema_n
        delta_2 = S - ema_m

        sum_delta = (self.m * delta_1 + self.n * delta_2)/(self.n+self.m)
        m_plus=sum_delta.where(sum_delta>0)
        m_moins=sum_delta.where(sum_delta < 0,-1)

        m = m_moins.eq(m_moins.where(m_moins != 0).max(1), axis=0).astype(int)
        m_plus.iloc[np.where(m_plus.sum(axis=1) == 0)[0]] = m.iloc[np.where(m_plus.sum(axis=1) == 0)[0]]


        w = m_plus

        # normalize so that they sum to 1
        w = w.div(w.sum(axis=1), axis=0).fillna(0)  # Na's if downcreasing trend for all underlying assets

        return w
